import React from 'react'
import { useEffect } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ScrollSmoother } from 'gsap/ScrollSmoother'
import Navbar from './components/Navbar'
import HeroSection from './components/HeroSection'
import TechLogosSection from './components/TechLogosSection'
import FeatureCards from './components/FeatureCards'
import VoiceAssistantSection from './components/VoiceAssistantSection'
import Footer from './components/Footer'

// GSAP eklentilerini kaydet - ScrollTrigger önce kaydedilmeli
gsap.registerPlugin(ScrollTrigger)
gsap.registerPlugin(ScrollSmoother)

function App() {
  useEffect(() => {
    // ScrollSmoother'ı başlat
    const smoother = ScrollSmoother.create({
      wrapper: '#smooth-wrapper',
      content: '#smooth-content',
      smooth: 1.5, // Yumuşaklık seviyesi (0-3 arası)
      effects: true, // data-speed efektlerini etkinleştir
      smoothTouch: 0.1, // Mobil cihazlarda yumuşaklık
      normalizeScroll: true, // Farklı cihazlarda tutarlılık
      ignoreMobileResize: true, // Mobil resize sorunlarını önle
    })

    // Cleanup function
    return () => {
      if (smoother) {
        smoother.kill()
      }
    }
  }, [])

  return (
    <div id="smooth-wrapper" className="app">
      <Navbar />
      <div id="smooth-content">
        <div className="scroll-section">
          <HeroSection />
        </div>
        <div className="scroll-section">
          <FeatureCards />
        </div>
        <div className="scroll-section">
          <TechLogosSection />
        </div>
        <div className="scroll-section">
          <VoiceAssistantSection />
        </div>
        <Footer />
      </div>
    </div>
  )
}

export default App