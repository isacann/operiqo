import React, { useState, useEffect } from 'react'
import '../styles/DemoForm.css'

interface DemoFormProps {
  onFormComplete: () => void
}

interface FormData {
  name: string
  email: string
  phone: string
  sector: string
  company: string
  message: string
}

const DemoForm: React.FC<DemoFormProps> = ({ onFormComplete }) => {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    sector: '',
    company: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [submissionError, setSubmissionError] = useState<string | null>(null)

  const steps = [
    {
      id: 'name',
      title: 'Adınız nedir?',
      placeholder: 'Adınızı yazın...',
      type: 'text',
      field: 'name' as keyof FormData
    },
    {
      id: 'email',
      title: 'E-posta adresiniz?',
      placeholder: 'ornek@email.com',
      type: 'email',
      field: 'email' as keyof FormData,
      note: '(demo gönderebilmemiz için)'
    },
    {
      id: 'phone',
      title: 'Telefon numaranız?',
      placeholder: '5XXXXXXXX',
      type: 'tel',
      field: 'phone' as keyof FormData,
      note: 'Başında 0 olmadan giriniz (Sesli asistan tarafından aranabilirsiniz)'
    },
    {
      id: 'sector',
      title: 'Hizmet verdiğiniz sektör?',
      placeholder: 'Örn: E-ticaret, Diş Kliniği vb.',
      type: 'text',
      field: 'sector' as keyof FormData
    },
    {
      id: 'company',
      title: 'İşletmenizin adı?',
      placeholder: 'İşletmenizin adını yazın...',
      type: 'text',
      field: 'company' as keyof FormData
    },
    {
      id: 'message',
      title: 'Sesli asistanın hangi özelliğini merak ediyorsunuz?',
      placeholder: 'Müşteri formu ile tetiklenen aramalar, gelen çağrılar, giden çağrılar vs...',
      type: 'textarea',
      field: 'message' as keyof FormData
    }
  ]

  const currentStepData = steps[currentStep]

  const handleInputChange = (value: string) => {
    if (currentStepData) {
      setFormData(prev => ({
        ...prev,
        [currentStepData.field]: value
      }))
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && isCurrentStepValid()) {
      e.preventDefault()
      handleNext()
    }
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1)
    } else {
      handleSubmit()
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1)
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    setSubmissionError(null)
    
    try {
      const response = await fetch('https://n8n.srv857453.hstgr.cloud/webhook/9e6b54ca-fbc5-491a-a3c7-b38bd0aebf7d', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        setIsSubmitted(true)
        setSubmissionError(null)
        
        // 3 saniye sonra formu kapat
        setTimeout(() => {
          onFormComplete()
          // Form durumunu sıfırla
          setCurrentStep(0)
          setFormData({
            name: '',
            email: '',
            phone: '',
            sector: '',
            company: '',
            message: ''
          })
          setIsSubmitted(false)
          setSubmissionError(null)
        }, 3000)
      } else {
        throw new Error('Gönderim başarısız')
      }
    } catch (error) {
      console.error('Form gönderim hatası:', error)
      setSubmissionError('Daha sonra tekrar deneyiniz')
      setIsSubmitted(false)
    } finally {
      setIsSubmitting(false)
    }
  }

  const isCurrentStepValid = () => {
    if (!currentStepData) return false
    const value = formData[currentStepData.field]
    
    // Telefon validasyonu - tam 10 karakter olmalı
    if (currentStepData.field === 'phone') {
      return value.trim().length === 10
    }
    
    // E-posta validasyonu - @ sembolü zorunlu
    if (currentStepData.field === 'email') {
      return value.trim().length > 0 && value.includes('@')
    }
    
    // Diğer alanlar için genel validasyon
    return value.trim().length > 0
  }

  const handleClose = () => {
    onFormComplete()
  }

  if (isSubmitted) {
    return (
      <div className="demo-form-container submitted">
        <div className="demo-form-success">
          <div className="success-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
              <polyline points="22,4 12,14.01 9,11.01"/>
            </svg>
          </div>
          <h3>Teşekkürler!</h3>
          <p>Demo talebiniz başarıyla gönderildi. En kısa sürede sizinle iletişime geçeceğiz.</p>
        </div>
      </div>
    )
  }

  if (isSubmitting) {
    return (
      <div className="demo-form-container submitting">
        <div className="demo-form-loading">
          <div className="loading-spinner"></div>
          <h3>Gönderiliyor...</h3>
          <p>Demo talebiniz işleniyor, lütfen bekleyin.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="demo-form-container">
      <div className="demo-form-header">
        <button className="demo-form-close" onClick={handleClose}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
        <div className="demo-form-progress">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
          <span className="progress-text">{currentStep + 1} / {steps.length}</span>
        </div>
      </div>

      <div className="demo-form-content">
        <div className="demo-form-step" key={currentStep}>
          <h3 className="step-title">{currentStepData?.title}</h3>
          
          <div className="step-input-container">
            {currentStepData?.type === 'textarea' ? (
              <textarea
                className="step-input step-textarea"
                placeholder={currentStepData.placeholder}
                value={formData[currentStepData.field]}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={4}
                autoFocus
              />
            ) : (
              <input
                className="step-input"
                type={currentStepData?.type}
                placeholder={currentStepData?.placeholder}
                value={formData[currentStepData?.field || 'name']}
                onChange={(e) => handleInputChange(e.target.value)}
                onKeyDown={handleKeyDown}
                maxLength={currentStepData?.field === 'phone' ? 10 : undefined}
                autoFocus
              />
            )}
            {currentStepData?.note && (
              <p className="step-input-note">{currentStepData.note}</p>
            )}
          </div>

          <div className="demo-form-actions">
            {submissionError && (
              <div className="submission-error">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="15" y1="9" x2="9" y2="15"/>
                  <line x1="9" y1="9" x2="15" y2="15"/>
                </svg>
                {submissionError}
              </div>
            )}
            <div className="demo-form-actions-buttons">
              {currentStep > 0 && (
                <button 
                  className="demo-form-btn demo-form-btn-back"
                  onClick={handleBack}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m15 18-6-6 6-6"/>
                  </svg>
                  Geri
                </button>
              )}
              
              <button 
                className={`demo-form-btn demo-form-btn-next ${!isCurrentStepValid() ? 'disabled' : ''}`}
                onClick={handleNext}
                disabled={!isCurrentStepValid()}
              >
                {currentStep === steps.length - 1 ? 'Gönder' : 'Devam'}
                {currentStep < steps.length - 1 && (
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m9 18 6-6-6-6"/>
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DemoForm