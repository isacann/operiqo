import React from 'react'
import { useInView } from 'react-intersection-observer'
import '../styles/TechLogosSection.css'
import n8nLogo from '../assets/n8n copy.png'
import elevenLabsLogo from '../assets/elevenlabs-logo-white copy.png'
import openAILogo from '../assets/openai-white-lockup copy.png'
import supabaseLogo from '../assets/supabase-logo-wordmark--dark.png'
import aiPlatformLogo from '../assets/Adsız tasarım (64) copy.png'

const TechLogosSection: React.FC = () => {
  const { ref, inView } = useInView({
    threshold: 0.5,
    triggerOnce: true
  })

  // Teknoloji logoları
  const techLogos = [
    {
      name: 'n8n',
      url: n8nLogo
    },
    {
      name: 'ElevenLabs',
      url: elevenLabsLogo
    },
    {
      name: 'AI Platform',
      url: aiPlatformLogo
    },
    {
      name: 'OpenAI',
      url: openAILogo
    },
    {
      name: 'Supabase',
      url: supabaseLogo
    },
    {
      name: 'n8n',
      url: n8nLogo
    },
    {
      name: 'ElevenLabs',
      url: elevenLabsLogo
    },
    {
      name: 'AI Platform',
      url: aiPlatformLogo
    },
    {
      name: 'OpenAI',
      url: openAILogo
    },
    {
      name: 'Supabase',
      url: supabaseLogo
    }
  ]

  return (
    <section className={`tech-logos-section ${inView ? 'animate' : ''}`} ref={ref}>
      <div className="tech-logos-container">
        <h2 className="tech-logos-title">Kullandığımız Teknolojiler</h2>
        
        <div className="tech-logos-slider">
          <div className="tech-logos-track">
            {/* İlk set logolar */}
            {techLogos.map((tech, index) => (
              <div key={`first-${index}`} className="tech-logo-item">
                <img 
                  src={tech.url} 
                  alt={tech.name}
                  className="tech-logo-image"
                />
              </div>
            ))}
            
            {/* İkinci set logolar (sürekli döngü için) */}
            {techLogos.map((tech, index) => (
              <div key={`second-${index}`} className="tech-logo-item">
                <img 
                  src={tech.url} 
                  alt={tech.name}
                  className="tech-logo-image"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default TechLogosSection