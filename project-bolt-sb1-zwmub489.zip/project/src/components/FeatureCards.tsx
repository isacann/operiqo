import React, { useState, useEffect } from 'react'
import { useInView } from 'react-intersection-observer'
import '../styles/FeatureCards.css'

const FeatureCards: React.FC = () => {
  const [efficiency, setEfficiency] = useState(0)
  const [cost, setCost] = useState(0)
  
  const { ref, inView } = useInView({
    threshold: 0.5,
    triggerOnce: true
  })

  useEffect(() => {
    if (inView) {
      // Verimlilik animasyonu - kartlar görünür olduktan 2 saniye sonra başlar
      const efficiencyTimer = setTimeout(() => {
        let current = 0
        const target = 25
        const increment = target / 50
        const interval = setInterval(() => {
          current += increment
          if (current >= target) {
            current = target
            clearInterval(interval)
          }
          setEfficiency(Math.round(current))
        }, 30)
      }, 100)

      // Maliyet tasarrufu animasyonu - kartlar görünür olduktan 2.1 saniye sonra başlar
      const costTimer = setTimeout(() => {
        let current = 0
        const target = 25
        const increment = target / 50
        const interval = setInterval(() => {
          current += increment
          if (current >= target) {
            current = target
            clearInterval(interval)
          }
          setCost(Math.round(current))
        }, 30)
      }, 150)

      return () => {
        clearTimeout(efficiencyTimer)
        clearTimeout(costTimer)
      }
    }
  }, [inView])

  return (
    <section className={`feature-cards-section ${inView ? 'animate' : ''}`} ref={ref}>
      <div className="feature-cards-container">
        {/* İlk Kart - Verimlilik Artışı */}
        <div className="feature-card">
          <div className="feature-card-visual-area">
            <div className="feature-card-animated-bg"></div>
            <div className="feature-card-icon-wrapper">
              {/* Yukarı Ok İkonu */}
              <svg className="feature-card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#DC7814" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 19V5M5 12l7-7 7 7"/>
              </svg>
            </div>
          </div>
          <div className="feature-card-text-content">
            <div className="feature-card-percentage">+%{efficiency}</div>
            <h2>Verimlilik Artışı</h2>
            <p>Yapay zekâ destekli otomasyon kullanan işletmeler verimliliğini en az %25 artırdığını bildirdi.</p>
            <a href="https://www.redwood.com/press-releases/enterprise-automation-index-2025-73-of-companies-increased-automation-spend-nearly-40-report-at-least-25-cost-reduction/" target="_blank" rel="noopener noreferrer" className="source-link">
              Kaynak
            </a>
          </div>
        </div>

        {/* İkinci Kart - Maliyet Tasarrufu */}
        <div className="feature-card">
          <div className="feature-card-visual-area">
            <div className="feature-card-animated-bg"></div>
            <div className="feature-card-icon-wrapper">
              {/* Dolar İşareti İkonu */}
              <svg className="feature-card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#DC7814" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 1v22"></path>
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H7"></path>
              </svg>
            </div>
          </div>
          <div className="feature-card-text-content">
            <div className="feature-card-percentage">+%{cost}</div>
            <h2>Maliyet Tasarrufu</h2>
            <p>Yapay zekâ destekli otomasyon kullanan işletmeler maliyetlerini en az %25~50 düşürdüğünü bildirdi.</p>
            <a href="https://www.redwood.com/press-releases/enterprise-automation-index-2025-73-of-companies-increased-automation-spend-nearly-40-report-at-least-25-cost-reduction/" target="_blank" rel="noopener noreferrer" className="source-link">
              Kaynak
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default FeatureCards