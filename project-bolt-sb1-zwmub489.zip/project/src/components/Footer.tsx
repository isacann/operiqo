import React from 'react'
import '../styles/Footer.css'
import logo from '../assets/Adsız tasarım (25).png'

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Sol Taraf */}
        <div className="footer-left">
          {/* Logo */}
          <div className="footer-logo">
            <img src={logo} alt="Operiqo Logo" />
          </div>
          
          {/* Açıklama */}
          <p className="footer-description">
            Operiqo dijital otomasyon ajansı
          </p>
          
          {/* Privacy Policy */}
          <div className="footer-links">
            <a 
              href="#" 
              className="footer-link"
              onClick={(e) => e.preventDefault()}
            >
              Privacy Policy
            </a>
          </div>
          
          {/* E-posta */}
          <div className="footer-contact">
            <a href="mailto:team@operiqo.com" className="footer-email">
              <svg className="email-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                <polyline points="22,6 12,13 2,6"/>
              </svg>
              team@operiqo.com
            </a>
          </div>
          
          {/* Ayırıcı Çizgi */}
          <div className="footer-divider"></div>
          
          {/* Sosyal Medya */}
          <div className="footer-social">
            <a 
              href="https://www.linkedin.com/company/operiqo/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="social-link"
              aria-label="LinkedIn"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
                <rect width="4" height="12" x="2" y="9"/>
                <circle cx="4" cy="4" r="2"/>
              </svg>
            </a>
            
            <a 
              href="#" 
              className="social-link" 
              onClick={(e) => e.preventDefault()} 
              aria-label="X (Twitter)"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 4l11.733 16h4.267l-11.733 -16z"/>
                <path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/>
              </svg>
            </a>
            
            <a 
              href="#" 
              className="social-link" 
              onClick={(e) => e.preventDefault()} 
              aria-label="Instagram"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
              </svg>
            </a>
          </div>
        </div>
        
        {/* Sağ Taraf */}
        <div className="footer-right">
          {/* Şirket Bilgisi */}
          <div className="footer-company">
            <a 
              href="https://find-and-update.company-information.service.gov.uk/company/16564097"
              target="_blank"
              rel="noopener noreferrer"
              className="company-link"
            >
              İngiltere kayıtlı şirket
              <svg className="external-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M7 7h10v10"/>
                <path d="M7 17 17 7"/>
              </svg>
            </a>
          </div>
          
          {/* Telif Hakkı */}
          <div className="footer-copyright">
            © 2025 Operiqo tüm hakları saklıdır
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer