import React, { useState, useEffect } from 'react'
import '../styles/Navbar.css'
import logo from '../assets/Adsız tasarım (25).png'

const Navbar: React.FC = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<'tr' | 'en'>('tr')
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY
      
      // Sadece sayfa en üstteyse navbar'ı göster
      if (currentScrollY <= 10) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    
    return () => {
      window.removeEventListener('scroll', handleScroll)
    }
  }, [])

  return (
    <nav className={`navbar ${!isVisible ? 'hidden' : ''}`}>
      <div className="navbar-container">
        {/* Logo */}
        <div className="navbar-logo">
          <a href="/">
            <img src={logo} alt="Operigo Logo" />
          </a>
        </div>

        {/* Dil Seçimi */}
        <div className="language-selector">
          <button
            className={`language-btn ${selectedLanguage === 'tr' ? 'active' : ''}`}
            onClick={() => setSelectedLanguage('tr')}
          >
            Türkçe
          </button>
          <button
            className={`language-btn ${selectedLanguage === 'en' ? 'active' : ''}`}
            onClick={() => setSelectedLanguage('en')}
          >
            English
          </button>
        </div>
      </div>
    </nav>
  )
}

export default Navbar