import React from 'react'
import { useInView } from 'react-intersection-observer'
import '../styles/SolutionCards.css'

const SolutionCards: React.FC = () => {
  const { ref, inView } = useInView({
    threshold: 0.3,
    triggerOnce: true
  })

  return (
    <section className={`solution-cards-section ${inView ? 'animate' : ''}`} ref={ref}>
      <div className="solution-cards-container">
        
        {/* Entegrasyon Kolaylığı Kartı */}
        <div className="solution-card integration-card">
          <div className="solution-card-visual">
            <div className="integration-visual">
              <div className="integration-systems">
                <div className="system system-left"></div>
                <div className="system system-right"></div>
              </div>
              <div className="integration-bridge">
                <div className="bridge-line"></div>
                <div className="data-flow"></div>
              </div>
              <div className="integration-gears">
                <div className="gear gear-1"></div>
                <div className="gear gear-2"></div>
              </div>
            </div>
          </div>
          <div className="solution-card-content">
            <h2>Entegrasyon Kolaylığı</h2>
            <p>Sesli asistanlarımız mevcut altyapınıza kolayca uyum sağlar. Hızlı ve sorunsuz entegrasyon sayesinde, iş süreçlerinizi kısa sürede otomatikleştirip verimliliğinizi artırmaya başlayın.</p>
          </div>
        </div>

        {/* Müşteri Memnuniyeti Kartı */}
        <div className="solution-card satisfaction-card">
          <div className="solution-card-visual">
            <div className="satisfaction-visual">
              <div className="clock-face">
                <div className="clock-center"></div>
                <div className="clock-hand hour-hand"></div>
                <div className="clock-hand minute-hand"></div>
                <div className="clock-numbers">
                  <div className="number number-12">24</div>
                  <div className="number number-3">7</div>
                </div>
              </div>
              <div className="service-rings">
                <div className="ring ring-1"></div>
                <div className="ring ring-2"></div>
                <div className="ring ring-3"></div>
              </div>
              <div className="satisfaction-sparkles">
                <div className="sparkle sparkle-1"></div>
                <div className="sparkle sparkle-2"></div>
                <div className="sparkle sparkle-3"></div>
                <div className="sparkle sparkle-4"></div>
              </div>
            </div>
          </div>
          <div className="solution-card-content">
            <h2>Müşteri Memnuniyetini Artırın</h2>
            <p>Gelen çağrıları anında yanıtlayan, başvuru-kayıt gönderen müşteriyi anında arayan yapay zekâ asistanları ile müşteri bekleme sürelerini azaltın, 7/24 kesintisiz hizmet sunarak müşteri memnuniyetini zirveye taşıyın.</p>
          </div>
        </div>

        {/* Maliyet Azaltma Kartı */}
        <div className="solution-card cost-card">
          <div className="solution-card-visual">
            <div className="cost-visual">
              <div className="chart-bars">
                <div className="bar bar-1"></div>
                <div className="bar bar-2"></div>
                <div className="bar bar-3"></div>
                <div className="bar bar-4"></div>
                <div className="bar bar-5"></div>
              </div>
              <div className="cost-arrow"></div>
              <div className="cost-sparkles">
                <div className="sparkle sparkle-1"></div>
                <div className="sparkle sparkle-2"></div>
                <div className="sparkle sparkle-3"></div>
              </div>
            </div>
          </div>
          <div className="solution-card-content">
            <h2>Maliyetlerinizi Azaltın, Verimliliği Artırın</h2>
            <p>Sesli yapay zekâ çözümlerimizle manuel iş yükünü hafifletin, operasyon maliyetlerinizi düşürün ve personelinizin stratejik görevlere odaklanmasını sağlayarak işletmenizi ileriye taşıyın.</p>
          </div>
        </div>

      </div>
    </section>
  )
}

export default SolutionCards