import React from 'react'
import { useInView } from 'react-intersection-observer'
import '../styles/VoiceAssistantSection.css'
import SolutionCards from './SolutionCards'
import DemoForm from './DemoForm'

const VoiceAssistantSection: React.FC = () => {
  const [showDemoForm, setShowDemoForm] = React.useState(false)
  
  const { ref, inView } = useInView({
    threshold: 0.3,
    triggerOnce: true
  })

  const handleDemoClick = () => {
    setShowDemoForm(true)
  }

  const handleFormComplete = () => {
    setShowDemoForm(false)
  }

  return (
    <section className={`voice-assistant-section ${inView ? 'animate' : ''}`} ref={ref}>
      <div className="voice-assistant-container">
        <h2 className="voice-assistant-title">
          <svg className="voice-assistant-title-icon" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
            <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
            <path d="M12 19v3"/>
            <path d="M8 23h8"/>
            <circle cx="12" cy="8" r="1"/>
          </svg>
          İşletmeniz İçin 7/24 Çalışan Akıllı Sesli Asistanlar
        </h2>
        
        <div className={`voice-assistant-content ${inView ? 'animate' : ''}`}>
          {/* Sol İçerik */}
          <div className="content-item left">
            <p>
              <svg className="phone-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
              </svg>
              <span className="main-text">Sizin yerinize arama yapar</span>
              <span className="description-text">Müşteriyle ilk teması kurar, bilgiyi toplar, fırsata dönüştürür.</span>
            </p>
          </div>
          
          {/* Merkez İkon */}
          <div className="center-icon-wrapper">
            <svg className="robot-icon" xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect width="18" height="10" x="3" y="11" rx="2"/>
              <circle cx="12" cy="5" r="2"/>
              <path d="m12 7 0 4"/>
              <line x1="8" x2="8" y1="16" y2="16"/>
              <line x1="16" x2="16" y1="16" y2="16"/>
            </svg>
          </div>
          
          {/* Sağ İçerik */}
          <div className="content-item right">
            <p>
              <svg className="phone-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
              </svg>
              <span className="main-text">Gelen çağrıları karşılar</span>
              <span className="description-text">Soruları yanıtlar, randevu alır, talepleri yönlendirir.</span>
            </p>
          </div>
          
          {/* Bağlantı Çizgileri */}
          <div className="voice-connection-line-left"></div>
          <div className="voice-connection-line-right"></div>
        </div>
        
        {/* Solution Cards - 3 Çözüm Kartı */}
        <SolutionCards />
        
        {/* Alt Satır - CTA ve Widget / Demo Form */}
        {showDemoForm ? (
          <div className={`voice-assistant-bottom-row ${inView ? 'animate' : ''}`}>
            <DemoForm onFormComplete={handleFormComplete} />
          </div>
        ) : (
          <div className={`voice-assistant-bottom-row ${inView ? 'animate' : ''}`}>
            {/* Ana CTA Butonu */}
            <button className="main-cta-button" onClick={handleDemoClick}>
              <svg className="main-cta-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
              </svg>
              Demo Alın
            </button>
            
            {/* Widget Alanı */}
            <div className="voice-widget-container">
              <div className="voice-widget-header">
                <svg className="voice-widget-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect width="18" height="10" x="3" y="11" rx="2"/>
                  <circle cx="12" cy="5" r="2"/>
                  <path d="m12 7 0 4"/>
                  <line x1="8" x2="8" y1="16" y2="16"/>
                  <line x1="16" x2="16" y1="16" y2="16"/>
                  <circle cx="9" cy="14" r="0.5"/>
                  <circle cx="15" cy="14" r="0.5"/>
                </svg>
                <h3>Sesli Asistanımızı Deneyin</h3>
              </div>
              <p className="voice-widget-instruction-text">
                <span className="highlight-text">Sağ alt köşedeki butona tıklayın!</span>
              </p>
              <p className="voice-widget-note-text">
                * Bu sesli asistan web tarayıcınız üzerinden çalışmaktadır.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

export default VoiceAssistantSection