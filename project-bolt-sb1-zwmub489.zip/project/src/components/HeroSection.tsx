import React from 'react'
import { useInView } from 'react-intersection-observer'
import '../styles/HeroSection.css'
import heroImage from '../assets/Adsız tasarım (20).png'
import profilePhoto from '../assets/isa3.png'

const HeroSection: React.FC = () => {
  const { ref, inView } = useInView({
    threshold: 0.5,
    triggerOnce: true
  })

  return (
    <section className="hero-section" ref={ref}>
      <div className="hero-container">
        <div className={`hero-content ${inView ? 'animate' : ''}`}>
          <h1 className="hero-title">
            Bir adım değil, bir sistemde olun.
          </h1>
          <div className={`hero-line ${inView ? 'animate' : ''}`}></div>
          <p className="hero-subtitle">
            AI gücünü, iş süreçlerinize entegre ederek sürdürülebilir büyümenize ortak oluyoruz.
          </p>
          
          {/* CTA Button */}
          <div className={`cta-button-container ${inView ? 'animate' : ''}`}>
            <button 
              className="cta-button"
              data-cal-link="isa-nurdogdu/tanısma-toplantısı"
              data-cal-namespace="tanısma-toplantısı"
              data-cal-config='{"layout":"month_view"}'
            >
              <div className="cta-content-wrapper">
                <div className="cta-visual-container">
                  <svg className="cta-action-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                  <img src={profilePhoto} alt="İsa - Kurucu" className="cta-hover-image" />
                </div>
                <div className="cta-text-area">
                  <div className="cta-text-initial">
                    Birlikte Başlayalım
                  </div>
                  <div className="cta-text-hover">
                    İsa ile toplantı
                    <span className="cta-text-hover-small">Kurucu - Operiqo</span>
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>
        
        {/* Sağ taraf görseli */}
        <div className={`hero-image-container ${inView ? 'animate' : ''}`}>
          <img 
            src={heroImage} 
            alt="AI Automation" 
            className="hero-right-image"
          />
          <div className="hero-image-lines">
            <div className="line line-1"></div>
            <div className="line line-2"></div>
            <div className="line line-3"></div>
          </div>
        </div>
      </div>
      <div className="spotlight-overlay"></div>
    </section>
  )
}

export default HeroSection